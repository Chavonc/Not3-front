import 'dart:convert';

List<Post> postFromJson(String str) =>List<Post>.from(json.decode(str).map((x) => Post.fromJson(x)));
String postToJson(List<Post> data) =>json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Post 
{
  Post//我們要什麼資料?
  ({
    //自己設的
    required this.account,//non-null
    required this.password,//non-null
    required this.status,
  });
  //related attribute
  String account;
  String password;
  String status;

  factory Post.fromJson(Map<String, dynamic> json) => Post//你要什麼東西
  (
    account: json['account'],
    password: json['password_hash'],
    status:json['gardener_status'],
  );
  Map<String, dynamic> toJson() => //他資料庫裡的對應
  {
    "account":account,
    "password_hash":password,
    "gardener_status":status,
  };
}
