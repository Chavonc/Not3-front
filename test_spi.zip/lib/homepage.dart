import 'package:flutter/material.dart';
import 'package:test_spi/models/get_test.dart';
import 'package:test_spi/services/getservice_test.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  // ignore: library_private_types_in_public_api
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Post>? posts;
  var isLoaded = false;
  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async 
  {
    posts = await RemoteService().getPosts();
    if (posts != null) {
      setState(() {
        isLoaded = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gardeners Get Posts'),
      ),
      body: Visibility
      (
        visible: isLoaded,
        replacement: const Center
        (
          child: CircularProgressIndicator(),
        ),
        child:ListView.builder
        (
          itemCount: posts?.length,
          itemBuilder: (context, index) 
          {
            return Container
            (
              padding: const EdgeInsets.all(0),
              child: Column
              (
                children:
                [
                  Text
                  (
                    posts![index].account,
                  ),
                  Text
                  (
                    posts![index].password,
                  ),
                  Text
                  (
                    posts![index].status,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
