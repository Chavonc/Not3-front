//import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:test_spi/models/get_test.dart';

class RemoteService 
{
  // ignore: body_might_complete_normally_nullable
  Future<List<Post>?> getPosts() async {
    var client = http.Client();
    var uri = Uri.parse("http://120.126.16.222/gardeners");
    var response = await client.get(uri);
    if (response.statusCode == 200) 
    {
      var json = response.body;
      return postFromJson(json);
    } 
  }
}