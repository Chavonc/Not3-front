import 'dart:convert';
import 'package:http/http.dart';
import 'package:flutter/foundation.dart';
import '../models/LoginModel.dart';

class LoginRepository//API_service
{
  String loginUrl = 'http://120.126.16.222/gardeners/login';

  Future<bool> checkLogin(String account,String password)async
  {
    try
    {
      final response=await post(Uri.parse(loginUrl),body:{'account':account,'password':password});
      if(response.statusCode==200)//請求成功
      {
        final List<dynamic> result=jsonDecode(response.body);
        final List<LoginModel> loginData=result.map((dynamic e)=>LoginModel.fromJson(e as Map<String,dynamic>)).toList();
        bool isMatch=false;// 檢查帳號和密碼是否匹配
        for(var login in loginData)
        {
          if (kDebugMode) 
          {
            print('Resopnse body:${response.body}');
          }
          if(login.account==account&&login.password==password)
          {
            isMatch=true;
            break;
          }
        }
        if(isMatch)
        {
          if(kDebugMode)
          {
            print('API回傳:帳號和密碼匹配');
          }
        }
        else
        {
          if(kDebugMode)
          {
            print('API回傳:帳號和密碼不匹配');
          }
        }
        return isMatch;
      }
      else
      {
        if (kDebugMode) 
        {
          print('API Error:${response.reasonPhrase}');
        }
        throw Exception(response.reasonPhrase);
      }
    }
    catch(error)
    {
      if (kDebugMode) 
      {
        print('API 請求錯誤：$error');
      }
      throw Exception(error.toString());
    }
  }
}
  // Future<LoginModel> getData() async 
  // {
  //   try
  //   {
  //     final response = await get(Uri.parse(loginUrl));
  //     if (response.statusCode == 200) 
  //     {
  //       final dynamic jsonData = jsonDecode(response.body);
  //       //print
  //       if (kDebugMode) 
  //       {
  //         print('Resopnse body:${response.body}');
  //       }
  //       return LoginModel.fromJson(jsonData);
  //     } 
  //     else 
  //     {
  //       throw Exception(response.reasonPhrase);
  //     }
  //   }
  //   catch(error)
  //   {
  //     throw Exception(error.toString());  
  //   }
  // }
// }
