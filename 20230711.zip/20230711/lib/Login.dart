// ignore: file_names
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_project/MyPage1.dart';
import 'package:flutter_project/Repository/LoginBloc_Repo.dart';
import 'package:flutter_project/blocs/Login_bloc.dart';
import 'package:flutter_project/blocs/Login_event.dart';
import 'package:flutter_project/HomePage.dart';
import 'package:flutter_project/blocs/Login_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_project/SignUp.dart';

class LoginPage extends StatelessWidget
{
  const LoginPage({Key?key}):super(key:key);
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
    (
      appBar: AppBar
      (
        title:const Center(child:Text("登入")),
        backgroundColor: Colors.green,
      ),
      body:BlocProvider<LoginBloc>
      (
        create:(context)=>LoginBloc(),
        child:BlocListener<LoginBloc,LoginState>
        (
          listener:(context, state)
          {
            if(state is CheckInputState)
            {
              if(state.isValid)
              {
                if (kDebugMode) 
                {
                  print("LoginPage-CheckInputState格式正確");
                }
                // 登入按鈕被按下
                if(state.account!=null&&state.password!=null)
                {
                  BlocProvider.of<LoginBloc>(context).add
                  (
                    LoginButtonPressed
                    (
                      account: state.account!, 
                      password: state.password!,
                    )
                  );
                }
                // Navigator.push
                // (
                //   context,MaterialPageRoute(builder: (context) => const MyPage1()),
                // );
              }
              else 
              {
                if(kDebugMode)
                {
                  print("LoginPage-CheckInputState帳號或密碼為空");
                }
                BlocProvider.of<LoginBloc>(context).add(ErrorEvent());
                // Navigator.push
                // (
                //   context,MaterialPageRoute(builder: (context) => const HomePage()),
                // );
              }
            }
            else if(state is GoSignUpState)
            {
              if (kDebugMode) 
              {
                print("LoginPage-GoSignUpState請去註冊");
              }
              final loginRepository=LoginRepository();
              loginRepository.checkLogin(state.account!,state.password!).then((isMatch)
              {
                if(isMatch)
                {
                  BlocProvider.of<LoginBloc>(context).add(LoginSuccessEvent());
                }
                else
                {
                  BlocProvider.of<LoginBloc>(context).add(GoSignUpEvent());
                }
              }).catchError((error)
              {
                BlocProvider.of<LoginBloc>(context).add(ErrorEvent());
              });
              Navigator.push
              (
                context,MaterialPageRoute(builder: (context) => const SignUpPage()),
              );
            }
            else if(state is ErrorState)
            {
              if (kDebugMode) 
              {
                print("LoginPage-ErrorState格式有錯誤");
                Navigator.push
                (
                  context,MaterialPageRoute(builder: (context) => const HomePage()),
                );
              }
              else
              {
                if (kDebugMode) 
                {
                  print("LoginPage-ErrorState格式沒有錯誤");;
                }
              }
            }
          },
          child:const LoginForm(),
        ),
      ),
    );
  }
}
class LoginForm extends StatefulWidget
{
  const LoginForm({Key?key}):super(key:key);
  @override
  // ignore: library_private_types_in_public_api
  _LoginFormState createState()=> _LoginFormState();
}
class _LoginFormState extends State<LoginForm>
{
  final TextEditingController _accountController=TextEditingController();
  final TextEditingController _passwordController=TextEditingController();
  @override
  void dispose()
  {
    _accountController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context)
  {
    return Container
    (
      padding: const EdgeInsets.all(16.0),
      child:Column
      (
        mainAxisAlignment: MainAxisAlignment.center,
        children:
        [
          Row
          (
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>
            [
              SizedBox
              (
                width:300,
                height:80,
                child: TextField
                (
                  controller:_accountController,
                  decoration: const InputDecoration
                  (
                    prefixIcon: Icon(Icons.person),
                    contentPadding: EdgeInsets.symmetric(vertical: 20),
                    labelText: "帳號",
                    hintText: "請輸入Email",
                  ),
                ),
              ),
            ],
          ),
          Row
          (
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>
            [
              SizedBox
              (
                width:300,
                height:80,
                child:TextField
                (
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration
                  (
                    prefixIcon: Icon(Icons.lock),
                    labelText: "密碼",
                    hintText: "請輸入密碼",
                  ),
                ),
              ),
            ],
          ),
          Row
          (
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>
            [
              SizedBox
              (
                height:48.0,
                width:150,
                child:TextButton
                (
                  child:const Text("登入"),
                  onPressed: ()
                  {
                    _loginButtonPressed(context);
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  void _loginButtonPressed(BuildContext context)
  {
    String account= _accountController.text;
    String password=_passwordController.text;
    final loginRepository=LoginRepository();
    loginRepository.checkLogin(account, password).then((isMatch)//比對
    {
      if(isMatch)
      {
        BlocProvider.of<LoginBloc>(context).add(LoginSuccessEvent());
      }
      else
      {
        BlocProvider.of<LoginBloc>(context).add(GoSignUpEvent());
      }
    }).catchError((error)
    {
      BlocProvider.of<LoginBloc>(context).add(ErrorEvent());
    });
    
    BlocProvider.of<LoginBloc>(context).add
    (
      LoginButtonPressed(account: account,password: password),
    );
  }
}