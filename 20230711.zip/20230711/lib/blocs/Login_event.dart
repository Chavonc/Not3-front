import 'package:equatable/equatable.dart';

abstract class LoginEvent extends Equatable 
{
  const LoginEvent();
  @override
  List<Object?> get props => [];
}
class LoginButtonPressed extends LoginEvent
{
  final String account;
  final String password;
  const LoginButtonPressed({required this.account,required this.password});
  @override
  List<Object?> get props => [account,password];
}
class LoginSuccessEvent extends LoginEvent{}
class GoSignUpEvent extends LoginEvent{}
class ErrorEvent extends LoginEvent{}