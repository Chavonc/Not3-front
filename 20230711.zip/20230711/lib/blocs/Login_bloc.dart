import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_project/blocs/Login_event.dart';
import 'package:flutter_project/blocs/Login_state.dart';
class LoginBloc extends Bloc<LoginEvent, LoginState> 
{
  LoginBloc():super(InitState());
  @override
  Stream<LoginState> mapEventToState(LoginEvent event) async*
  {
    if(event is LoginButtonPressed)
    {
      yield* _mapLoginButtonPressedToState(event);
    }
    else if(event is LoginSuccessEvent)
    {
      yield* _mapLoginSuccessEventToState(event);
    }
    else if(event is GoSignUpEvent)
    {
      yield* _mapGoSignUpEventToState(event);
    }
    else if(event is ErrorEvent)
    {
      yield* _mapErrorEventToState(event);
    }
  }
  Stream<LoginState> _mapLoginButtonPressedToState(LoginButtonPressed event)async*
  {
    try
    {
      if(event.account.isEmpty||event.password.isEmpty)// 檢查使用者是否有在TextField裡輸入資料
      {
        if(kDebugMode)
        {
          print("資料未輸入完整");
        }
        yield const CheckInputState(false);// 沒有輸入資料
        yield ErrorState();
      }
      else
      {
        if(kDebugMode)
        {
          print("資料已輸入完整");
        }
        yield const CheckInputState(true,account:null,password:null);// 有輸入資料
        yield InputDataState(event.account, event.password);// 使用者已輸入資料，觸發 InputDataState 事件
      }
    }
    catch(error)
    {
      if (kDebugMode) 
      {
        print('發生錯誤:');
        print('$error');
      }
      yield ErrorState();// 發生錯誤，發出ErrorState
    }
  }
  Stream<LoginState> _mapLoginSuccessEventToState(LoginSuccessEvent event)async*
  {
    if(kDebugMode) // 登入成功的處理邏輯
    {
      print("登入Successfully!");
    }
    // 處理登入成功的邏輯
  }
  Stream<LoginState> _mapGoSignUpEventToState(GoSignUpEvent event)async*
  {
    if(kDebugMode)// 前往註冊頁面的處理邏輯
    {
      print("Please go to Sign Up");
    }
    yield GoSignUpState();
  }
  Stream<LoginState> _mapErrorEventToState(ErrorEvent event)async*
  {
    if(kDebugMode)// 發生錯誤的處理邏輯
    {
      print("Login_Bloc格式有錯誤");
    }
    yield ErrorState();
  }
}
// Future<bool> checkAccountAndPassword(String account,String password)async
// {
//   return true;// 假設帳號密碼檢查成功
// }
