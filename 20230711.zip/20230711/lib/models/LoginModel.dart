//API
class LoginModel 
{
  //配合API用的list
  String? account;
  String? password;

  LoginModel({this.account, this.password});
  Map<String,dynamic> toJson()
  {
    return
    {
      'account':account,
      'password':password,
    };
  }
  factory LoginModel.fromJson(Map<String, dynamic> json) 
  {
    return LoginModel
    (
      account : json['account'],
      password : json['password'],
    );
  }
}