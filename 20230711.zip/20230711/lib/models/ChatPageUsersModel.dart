
class ChatPageUsersModel
{
  String name;
  String messageText;
  String imageURL;
  String time;
  ChatPageUsersModel
  (
    {
      required this.name,
      required this.messageText,
      required this.imageURL,
      required this.time,
    }
  );
}