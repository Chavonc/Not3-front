import 'package:test_spi/models/logout_test.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
class LogoutPage extends StatefulWidget 
{
  const LogoutPage({Key? key}) : super(key: key);
  @override
  // ignore: library_private_types_in_public_api
  _LogoutPageState createState() => _LogoutPageState();
}

class _LogoutPageState extends State<LogoutPage> 
{
  final TextEditingController _accountcontroller = TextEditingController();
  final TextEditingController _passwordcontroller = TextEditingController();
  Future<List<dynamic>>? _futureLogin;
  final _storage = FlutterSecureStorage(); // 用於存儲 access_token
  @override
  Widget build(BuildContext context) 
  {
    return Scaffold
    (
      appBar: AppBar
      (
        title: const Text('Gardeners Logout Data(Post) Post'),
      ),
      body: Container
      (
        alignment: Alignment.center,
        padding: const EdgeInsets.all(8),
        child: (_futureLogin == null) ? buildColumn() : buildFutureBuilder(),
      ),
    );
  }
   Future<void> saveAccessToken(String accessToken) async {
    // 使用 flutter_secure_storage 儲存 access_token
    await _storage.write(key: 'access_token', value: accessToken);
  }

  Future<String?> getAccessToken() async {
    // 從 flutter_secure_storage 取得 access_token
    return await _storage.read(key: 'access_token');
  }

  Future<void> deleteAccessToken() async {
    // 從 flutter_secure_storage 刪除 access_token
    await _storage.delete(key: 'access_token');
  }

  Future<void> showLoginSuccessDialog() async {
    // 登入成功時跳出 AlertBox 並刷新頁面
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('登入成功'),
        content: Text('按下 OK 按鈕將刷新頁面。'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _futureLogin = null; // 刷新頁面
              });
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> showLogoutResultDialog(String message) async {
    // 顯示登出 API 回傳的結果
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('登出結果'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
  Column buildColumn() 
  {
    return Column
    (
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>
      [
        SizedBox
        (
          width: 300,
          height: 80,
          child: TextField
          (
            controller: _accountcontroller,
            decoration: const InputDecoration
            (
              hintText: 'Enter Account',
              labelText: "帳號",
              prefixIcon: Icon(Icons.person),
            ),
          ),
        ),
        SizedBox(
          width: 300,
          height: 80,
          child: TextField(
            controller: _passwordcontroller,
            obscureText: true,
            decoration: const InputDecoration(
              hintText: 'Enter Password',
              labelText: "密碼",
              prefixIcon: Icon(Icons.lock),
            ),
          ),
        ),

          ElevatedButton
          (
            onPressed: () async
            {
              try
              {
                final result=await createLogin(_accountcontroller.text,_passwordcontroller.text);
                // 登入成功後，保存 access_token
                final accessToken = result[0]['access_token'];
                await saveAccessToken(accessToken);
                setState(() 
                {
                  _futureLogin = Future<List<dynamic>>.value(result);
                });
                // 顯示登入成功的 AlertBox
                await showLoginSuccessDialog();
              }
              catch (e) 
              {
                print('登入失敗：$e');
                setState(() 
                {
                  _futureLogin = null;
                });
              }
            },
            child: const Text('Login'),
          ),
        

        // 新增 logout 按鈕的 onPressed 方法
        ElevatedButton
        (
          onPressed: () async 
          {
            // 取得保存的 account 和 access_token
            final account = _accountcontroller.text;
            final savedAccessToken = await getAccessToken();

            if (savedAccessToken != null) 
            {
              // 呼叫登出 API
              try 
              {
                final response = await http.post
                (
                    Uri.parse('http://120.126.16.222/gardeners/logout'),
                    headers: <String, String>
                    {
                      'Content-Type': 'application/json',
                      'Authorization': 'Bearer $savedAccessToken',
                    },
                    body: jsonEncode(<String, String>
                    {
                      'account': account,
                      'access_token': savedAccessToken,
                    }),
                  );

                  if (response.statusCode == 200) 
                  {
                    // 登出成功
                    final body = jsonDecode(response.body);
                    final message = '登出成功\n資料：$body';
                    await showLogoutResultDialog(message);
                    await deleteAccessToken(); // 登出後刪除保存的 access_token
                    setState(() 
                    {
                      _futureLogin = null; // 刷新頁面
                    });
                  } 
                  else 
                  {
                    // 登出失敗
                    final errorMessage = response.body;
                    await showLogoutResultDialog(errorMessage);
                  }
                } 
                catch (e) 
                {
                  print('登出失敗：$e');
                  final errorMessage = '登出失敗：$e';
                  await showLogoutResultDialog(errorMessage);
                }
              } 
              else 
              {
                // 沒有保存的 access_token，直接顯示錯誤訊息
                final errorMessage = '尚未登入，無法進行登出。';
                await showLogoutResultDialog(errorMessage);
              }
          },
          child: const Text('Logout'),
        ),
      ],
    );
  }

  FutureBuilder<List<dynamic>> buildFutureBuilder() 
  {
    return FutureBuilder<List<dynamic>>
    (
      future: _futureLogin,
      builder: (context, snapshot) 
      {
        if (snapshot.connectionState == ConnectionState.waiting) 
        {
          return const CircularProgressIndicator();
        } 
        else if (snapshot.hasData) 
        {
          return ListView.builder
          (
            padding: const EdgeInsets.all(20),
            itemCount: snapshot.data!.length,
            itemBuilder: (context,index)
            {
              final item=snapshot.data![index];
              return ListTile
              (

                //title: Text('account:${item['account']}'),
                title: Text('access_token :${item['access_token']}'),
              );
            },
          );
        } 
        else if (snapshot.hasError) 
        {
          return Text('${snapshot.error}');
        } 
        else 
        {
          return const Text('No data available');
        }
      },
    );
  }
}