String APP_ID = ''; // 初始值留空
String ROOM_UUID = ''; // 初始值留空
String ROOM_TOKEN = ''; // 初始值留空
const String UNIQUE_CLIENT_ID = "123456";