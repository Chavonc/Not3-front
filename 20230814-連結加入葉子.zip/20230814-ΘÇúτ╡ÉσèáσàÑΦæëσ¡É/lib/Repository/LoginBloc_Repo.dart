import 'dart:convert';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
class LoginRepository//API_service
{
  final _storage = const FlutterSecureStorage(); // 用於存儲
  String url = 'http://120.126.16.222/gardeners/login';
  String? userPassword;//保存
  Future<List<dynamic>> login(String account,String password)async
  {
      final response=await http.post
      (
        Uri.parse(url),
        headers:<String,String>{'Content-Type': 'application/json;charset=UTF-8'},
        body:jsonEncode(<String,String>//編碼,你要給什麼資料?
        {
          //input
          'account': account,
          'password': password,
        }),
      );
      if(response.statusCode>=200&&response.statusCode<300)//請求成功
      {
        List<dynamic> body =jsonDecode(response.body);
        userPassword=password;// 登入成功時保存密碼
        await _storage.write(key: 'password', value: userPassword);//save in storage
        if(kDebugMode)
        {
          print('UserPassword: $userPassword');
        }
        return body;
      }
      else
      {
        //測試到底有沒有接收到資料
        log(response.body);
        log('${response.statusCode}');
        throw Exception('${response.reasonPhrase},${response.statusCode}');
      }
  }
}