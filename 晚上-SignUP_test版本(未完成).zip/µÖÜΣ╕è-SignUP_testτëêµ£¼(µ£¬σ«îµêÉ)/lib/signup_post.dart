import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
//import 'package:image_crop/image_crop.dart';
//import 'package:image_picker_web/image_picker_web.dart';
import 'package:test_spi/models/signup_test.dart';
import 'package:flutter/foundation.dart';
class SignUpPage extends StatefulWidget 
{
  const SignUpPage({Key? key}) : super(key: key);
  @override
  // ignore: library_private_types_in_public_api
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> 
{
  final TextEditingController _firstnamecontroller=TextEditingController();
  final TextEditingController _accountcontroller = TextEditingController();
  final TextEditingController _passwordcontroller = TextEditingController();
  Future<List>? _futureSignUp;
  File? _imageFile;//用來存放選擇的圖片
  Uint8List webImage=Uint8List(8);
  
  @override
  Widget build(BuildContext context) 
  {
    return Scaffold
    (
      appBar: AppBar
      (
        title: const Text('Gardeners SignUp Data(Post) Posts'),
      ),
      body: Container
      (
        alignment: Alignment.center,
        padding: const EdgeInsets.all(8),
        child: (_futureSignUp == null) ? buildColumn() : buildFutureBuilder(),
      ),
    );
  }
  Column buildColumn() 
  {
    return Column
    (
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>
      [
        GestureDetector
        (
          onTap: ()
          {
            _pickImage();
          },
          child: Container
          (
            width:250,
            height:150,
            decoration: BoxDecoration
            (
              color:Colors.grey,
              //shape: BoxShape.circle,
              borderRadius: BorderRadius.circular(3),
            ),
            child:_imageFile==null? 
            TextButton
            (
              onPressed: () 
              {  
                _pickImage();
              },
              child:const Text
              (
                '選擇照片',
                style: TextStyle(color:Colors.white,fontSize: 18),
              ),
            ):Image.memory(webImage,fit:BoxFit.cover,),
          ),
        ),
        SizedBox
        (
          width: 300,
          height: 80,
          child: TextField
          (
            controller: _accountcontroller,
            decoration: const InputDecoration
            (
              hintText: 'Enter Account',
              labelText: "帳號",
              prefixIcon: Icon(Icons.person_4),
            ),
          ),
        ),
        SizedBox
        (
          width: 300,
          height: 80,
          child: TextField
          (
            controller: _firstnamecontroller,
            decoration: const InputDecoration
            (
              hintText: 'Enter Firstname',
              labelText: "名字",
              prefixIcon: Icon(Icons.person),
            ),
          ),
        ),
        SizedBox
        (
          width: 300,
          height: 80,
          child: TextField
          (
            controller: _passwordcontroller,
            obscureText: true,
            decoration: const InputDecoration
            (
              hintText: 'Enter Password',
              labelText: "密碼",
              prefixIcon: Icon(Icons.lock),
            ),
          ),
        ),
        SizedBox
        (
          width: 250,
          height: 48,
          child: ElevatedButton
          (
            onPressed: () 
            {
              setState(() 
              {
                _futureSignUp = signup
                (
                  _accountcontroller.text,
                  _passwordcontroller.text,
                  _firstnamecontroller.text,
                  _imageFile!,// 送出選擇的圖片
                );
              });
            },
            child: const Text('show'),
          ),
        ),
      ],
    );
  }
  // 選擇照片或拍照的功能
  Future<void> _pickImage()async
  {
    if(!kIsWeb)
    {
      final ImagePicker picker=ImagePicker();
      final pickedFile=await picker.pickImage(source:ImageSource.gallery);
      if(pickedFile!=null)
      {
        var selected=File(pickedFile.path);
        setState(() 
        {
          _imageFile=selected;
          //_imageFile=File(pickedFile.path);
        });
      }
      else
      {
        if (kDebugMode) 
        {
          print("No image has been picked");
        }
      }
    }
    else if(kIsWeb)
    {
      final ImagePicker picker=ImagePicker();
      final pickedFile=await picker.pickImage(source:ImageSource.gallery);
      if(pickedFile!=null)
      {
        var f=await pickedFile.readAsBytes();
        setState(() 
        {
          webImage=f;
          _imageFile=File('a');
          //_imageFile=File(pickedFile.path);
        });
      }
      else
      {
        if (kDebugMode) 
        {
          print("No image has been picked");
        }
      }
      // final ImagePicker picker=ImagePicker();
      // final pickedFile=await picker.pickImage(source:ImageSource.gallery);
      // setState(() 
      // {
      //   _imageFile=File(pickedFile!.path);
      // });
    }
  
  }
  //controller
  FutureBuilder<List> buildFutureBuilder() 
  {
    return FutureBuilder<List<dynamic>>
    (
      future: _futureSignUp,
      builder: (context, snapshot) 
      {
        if (snapshot.connectionState == ConnectionState.waiting) 
        {
          return const CircularProgressIndicator();//保持loading
        } 
        else if (snapshot.hasData) 
        {
          return ListView.builder
          (
            padding: const EdgeInsets.all(20),
            itemCount: snapshot.data!.length,
            itemBuilder: (context,index)
            {
              final item=snapshot.data![index];
              return ListTile
              (
                title: Text('API Return:${item['error_message']}'),
              );
            },
          );
        } 
        else if (snapshot.hasError) 
        {
          return Text('${snapshot.error}');
        } 
        else 
        {
          return const Text('No data available');
        }
      },
    );
  }
}
