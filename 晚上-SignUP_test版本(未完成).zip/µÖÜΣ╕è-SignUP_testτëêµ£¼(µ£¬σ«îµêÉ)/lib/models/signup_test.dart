import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
//import 'package:image_picker/image_picker.dart';
// import 'package:flutter/foundation.dart';

class SignUpModel 
{
  //回傳什麼就設什麼
  final String errorMessage;
  const SignUpModel({required this.errorMessage});

  factory SignUpModel.fromJson(Map<String, dynamic> json) //API會給你的資料
  {
    return SignUpModel
    (
      //API return
      errorMessage: json['error_message'],
    );
  }
}
Future<List<dynamic>> signup(String account, String password,String firstname,File? file) async // Future<LoginModel>
{
  //建立請求
  final request=http.MultipartRequest
  (
    'POST',
    Uri.parse('http://120.126.16.222/gardeners/signup-test'),
  );
  //API required
  request.fields['account']='account';
  request.fields['password']='password';
  request.fields['first_name']='firstname';
  
  //封裝檔案資料並加入到 MultipartRequest，file must be upload
  if(file!=null&&!kIsWeb)
  {
    var fileStream=http.ByteStream(Stream.castFrom(file.openRead()));
    var fileLength=await file.length();
    var multipartFile=http.MultipartFile
    (
      'file',
      fileStream,
      fileLength,
      filename: file.path.split('/').last
    );
    request.files.add(multipartFile);
  }
  else if(file!=null&&kIsWeb)
  {
    var base64=base64Encode(file.readAsBytesSync());
    request.fields['file']=base64;
  }
  //使用 http.Client().send() 方法發送請求，處理回傳結果
  final response = await http.Client().send(request);
  var responseBody=await response.stream.bytesToString();
  if (response.statusCode>=200 && response.statusCode<300) 
  {
    //form-data
    List<dynamic> jsonResult=jsonDecode(responseBody);
    return jsonResult;
    //raw data
    // List<dynamic> body = jsonDecode(response.body);
    // return body;
  } 
  else //Error
  {
    //測試到底有沒有接收到資料
    //log(response.reasonPhrase);
    log('${response.statusCode}');
    throw Exception('${response.reasonPhrase},${response.statusCode}');
  }
}