abstract class AuthEvent {}

class LogoutEvent extends AuthEvent {}
