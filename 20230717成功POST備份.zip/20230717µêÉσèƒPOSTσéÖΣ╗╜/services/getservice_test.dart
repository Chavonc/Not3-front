//import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:test_spi/models/get_test.dart';

class RemoteService {
  // ignore: body_might_complete_normally_nullable
  Future<List<Post>?> getPosts() async {
    var client = http.Client();
    var uri = Uri.parse("http://120.126.16.222/gardeners");
    var response = await client.get(uri);
    if (response.statusCode == 200) 
    {
      var json = response.body;
      return postFromJson(json);
    } 
  }
}
// class RemoteService 
// {
//   void loginHttpForm(void Function() success, void Function() fail) async {
//     var urlString = "http://120.126.16.222/gardeners/login";
//     var client = new http.MultipartRequest("post", Uri.parse(urlString));
//     client.fields["account"] = "B0929036";
//     client.fields["gardener_status"] = "離線";
//     client.send().then((http.StreamedResponse response) {
//       if (response.statusCode == 200) {
//         response.stream.transform(utf8.decoder).join().then((String string) {
//           print("httpForm Success:$string");
//           success();
//         });
//       } else {
//         print("httpForm Fail:${response.statusCode}");
//         fail();
//       }
//     }).catchError((error) {
//       print("httpForm Fail:${error.toString()}");
//       fail();
//     });
//   }

//   getPosts() {}
// }
