import 'package:flutter/material.dart';
import 'package:test_spi/models/get_test.dart';

class HomePage extends StatefulWidget 
{
  const HomePage({Key? key}) : super(key: key);
  @override
  // ignore: library_private_types_in_public_api
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> 
{
  Future<List<dynamic>>? _futureGardeners;
  @override
  void initState() 
  {
    super.initState();
    _futureGardeners=fetchGardeners();
  }
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
    (
      appBar: AppBar
      (
        title: const Text('Gardeners (GET) Posts'),
      ),
      body: Container
      (
        alignment: Alignment.center,
        padding: const EdgeInsets.all(8),
        child:FutureBuilder<List<dynamic>>
        (
          future:_futureGardeners,
          builder:(context,snapshot)
          {
            if(snapshot.connectionState==ConnectionState.waiting)
            {
              return const CircularProgressIndicator();
            }
            else if(snapshot.hasData)
            {
              return ListView.builder//在螢幕上顯示的資料
              (
                padding:const EdgeInsets.all(20),
                itemCount: snapshot.data!.length,//告訴ListView有多少資料要顯示
                itemBuilder:(context,index)
                {
                  final item=snapshot.data![index];
                  return ListTile
                  (

                    title:Text('Account:${item['account']}'),
                    subtitle:Text('Status:${item['gardener_status']}'),
                  );
                }
              );
            }
            else if(snapshot.hasError)
            {
              return Text('${snapshot.error}');
            }
            return const CircularProgressIndicator();
          },
        ),
      ),
    );
  }
}
