import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
// List<Post> postFromJson(String str) =>List<Post>.from(json.decode(str).map((x) => Post.fromJson(x)));
// String postToJson(List<Post> data) =>json.encode(List<dynamic>.from(data.map((x) => x.toJson())));
class GardenersModel 
{
  final String account;
  //final String password;
  final String status;
  const GardenersModel//我們要什麼資料?
  ({
    //自己設的
    required this.account,//non-null
    //required this.password,//non-null
    required this.status,
  });

  factory GardenersModel.fromJson(Map<String, dynamic> json)
  //GET你要什麼東西
  {
    return GardenersModel
    (
      account: json['account'],
      //password: json['password_hash'],
      status: json['gardener_status'],
    );
  }
}
Future<List<dynamic>> fetchGardeners() async 
{
  final response=await http.get(Uri.parse('http://120.126.16.222/gardeners'));
  if (response.statusCode == 200) 
  {
    List<dynamic> body = jsonDecode(response.body);
    return body;
  } 
  else
  {
    //測試到底有沒有接收到資料
    log(response.body);
    log('${response.statusCode}');
    throw Exception('${response.reasonPhrase},${response.statusCode}');
  }
}
