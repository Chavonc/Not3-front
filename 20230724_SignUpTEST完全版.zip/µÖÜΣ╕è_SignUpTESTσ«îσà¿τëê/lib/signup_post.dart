import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:test_spi/models/signup_test.dart';

class SignUpPage extends StatefulWidget 
{
  const SignUpPage({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> 
{
  final TextEditingController _accountController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _firstNameController = TextEditingController();
  File? _imageFile;
  Uint8List? _imageBytes;
  String? _imageFileName;

  //URL
  Future<void> _signUp() async 
  {
    if (_imageFile == null && _imageBytes == null) 
    {
      // Handle case where image is not selected
      if (kDebugMode) 
      {
        print('還沒選擇頭像照片噢');
      }
      return;
    }

    final String account = _accountController.text;
    final String password = _passwordController.text;
    final String firstName = _firstNameController.text;
    if (account.isEmpty || password.isEmpty || firstName.isEmpty) 
    {
      // Handle case where any of the text fields is empty
      if (kDebugMode) 
      {
        print('資料輸入不完整');
      }
      return;
    }

    try 
    {
      // Create a multipart request
      final request = http.MultipartRequest
      (
        'POST',
        Uri.parse('http://120.126.16.222/gardeners/signup-test'),
      );

      // Add account, password, first_name as form data
      request.fields['account'] = account;
      request.fields['password'] = password;
      request.fields['first_name'] = firstName;

      // Add file as form data
      if (_imageFile != null) //for web,by ImagePicker returning PickedFile
      {
        final fileStream = http.ByteStream(Stream.castFrom(_imageFile!.openRead()));
        final fileLength = await _imageFile!.length();
        final multipartFile = http.MultipartFile
        (
          'file',
          fileStream,
          fileLength,
          filename: '$account.jpg',//file rename
        );
        request.files.add(multipartFile);
      } 
      else if (_imageBytes != null) //for IOS,by ImagePicker returning XFile
      {
        final multipartFile = http.MultipartFile.fromBytes
        (
          'file',
          _imageBytes!,
          filename: '$account.jpg',//file rename
        );
        request.files.add(multipartFile);
      }

      // Send the request and await for response
      final response = await http.Response.fromStream(await request.send());
      if (response.statusCode == 200) 
      {
        // Handle successful response
        final List<dynamic> jsonResult = jsonDecode(response.body);
        final List<SignUpModel> signUpModels = jsonResult.map((json) => SignUpModel.fromJson(json)).toList();
        final String errorMessage = signUpModels.first.errorMessage;
        _showResult(errorMessage);
      } 
      else 
      {
        // Handle error response
        _showResult('Error: ${response.statusCode}');
      }
    } 
    catch (e) 
    {
      // Handle any exceptions that occur during the process
      _showResult('Error: $e');
    }
  }

  Future<void> _pickImage(ImageSource source) async 
  {
    final ImagePicker picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) 
    {
      if (!kIsWeb) //IOS
      {
        setState(() 
        {
          _imageFile = File(pickedFile.path);
          _imageFileName=pickedFile.path.split('/').last;
        });
      } 
      else //Web
      {
        final bytes = await pickedFile.readAsBytes();
        setState(() 
        {
          _imageBytes = bytes;
          _imageFileName=pickedFile.name;
        });
      }
    } 
    else 
    {
      if (kDebugMode) 
      {
        print("No image has been picked");
      }
    }
  }
  Future<void> _showImageSourceDialog()async
  {
    await showDialog
    (
      context: context, 
      builder:(context)
      {
        return AlertDialog
        (
          title: const Text('選擇圖片來源'),
          content: Column
          (
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>
            [
              TextButton
              (
                onPressed: ()
                {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                }, 
                child: const Text('從相簿選擇')
              ),
              TextButton
              (
                onPressed: ()
                {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                }, 
                child: const Text('拍攝照片')
              ),
            ],
          ),
        );
      },
    );
  }


  void _showResult(String message) 
  {
    showDialog
    (
      context: context,
      builder: (context) 
      {
        return AlertDialog
        (
          title: const Text('API Response'),
          content: Text(message),
          actions: 
          [
            TextButton
            (
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Widget _getImageWidget()
  {
    const double imageSize=120.0;
    if(_imageFile!=null)
    {
      return ClipOval
      (
        child: Image.file
        (
          _imageFile!,
          width:imageSize,
          height: imageSize,
          fit:BoxFit.cover
        ),
      );
    }
    else if(_imageBytes!=null)
    {
      return ClipOval
      (
        child: Image.memory
        (
          _imageBytes!,
          width:imageSize,
          height: imageSize,
          fit:BoxFit.cover
        ),
      );
    }
    else
    {
      return GestureDetector
      (
        onTap:_showImageSourceDialog,
        child: Container
        (
          width: imageSize,
          height: imageSize,
          decoration: const BoxDecoration
          (
            color:Colors.grey,
            shape:BoxShape.circle,
          ),
          child:const Icon
          (
            Icons.camera_alt,
            color:Colors.white,
            size:40,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) 
  {
    return Scaffold
    (
      appBar: AppBar
      (
        title: const Text('Gardeners SignUp Data(Post) Posts'),
      ),
      body: Container
      (
        alignment: Alignment.center,
        padding: const EdgeInsets.all(8),
        child: Column
        (
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>
          [
            GestureDetector
            (
              onTap: _showImageSourceDialog,
              child: Container
              (
                width: 120,
                height: 120,
                decoration: const BoxDecoration
                (
                  color: Colors.grey,
                  shape: BoxShape.circle,
                ),
                child:_getImageWidget(),
              ),
            ),
            SizedBox
            (
              width: 300,
              height: 80,
              child: TextField
              (
                controller: _accountController,
                decoration: const InputDecoration
                (
                  hintText: 'Enter Account',
                  labelText: "帳號",
                  prefixIcon: Icon(Icons.person_2),
                ),
              ),
            ),
            SizedBox
            (
              width: 300,
              height: 80,
              child: TextField
              (
                controller: _firstNameController,
                decoration: const InputDecoration
                (
                  hintText: 'Enter Firstname',
                  labelText: "名字",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
            ),
            SizedBox
            (
              width: 300,
              height: 80,
              child: TextField
              (
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration
                (
                  hintText: 'Enter Password',
                  labelText: "密碼",
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
            ),
            SizedBox
            (
              width: 250,
              height: 48,
              child: ElevatedButton
              (
                onPressed: _signUp,
                child: const Text('SignUp'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}