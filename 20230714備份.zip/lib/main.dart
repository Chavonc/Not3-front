import 'package:flutter/material.dart';
import 'package:test_spi/homepage.dart';
import 'package:test_spi/login_post.dart';
void main()
{
  runApp(const MyApp());
}

class MyApp extends StatelessWidget
{
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp
    (
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}


// import 'dart:convert';
// import 'package:http/http.dart' as http;
//import 'package:dio/dio.dart';
// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:test_spi/services/postservice_test.dart';

// class Album {
//   //final int gardenerid;
//   final String account;
//   final String password;
//   const Album
//   ({
//     //required this.gardenerid, 
//     required this.account, 
//     required this.password
//   });

//   factory Album.fromJson(Map<String, dynamic> json) 
//   {
//     return Album(
//       //gardenerid: json['gardener_id'],
//       account: json['access_token']??'',
//       password: json['ip']??'',
//     );
//   }
// }

// Future<List<String>> createAlbum(String account, String password) async {
//   final response = await http.post(
//     Uri.parse('http://120.126.16.222/gardeners/login'),
//     headers: <String, String>{
//       'Content-Type': 'application/json; charset=UTF-8',
//       'accept':'application/json',
//     },
//     body: jsonEncode(<String, String>{
//       'access_token': account,
//       'ip': password,
//     }),
//   );

//   if (response.statusCode == 200) {
//     // If the server did return a 201 CREATED response,
//     // then parse the JSON.
//     final jsonData = jsonDecode(response.body) as List<dynamic>;
//     final album = Album.fromJson(jsonData[0]as Map<String,dynamic>);
//     return [album.account,album.password];//element[0]，[1]
//   } else {
//     // If the server did not return a 201 CREATED response,
//     // then throw an exception.
//     throw Exception('Error:${response.reasonPhrase},${response.statusCode}');
//   }
// }

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatefulWidget {
//   const MyApp({Key? key}):super(key:key);

//   @override
//   State<MyApp> createState() {
//     return _MyAppState();
//   }
// }

// class _MyAppState extends State<MyApp> {
//   final TextEditingController _accountcontroller = TextEditingController();
//   final TextEditingController _passwordcontroller = TextEditingController();
//   Future<List<String>>? _futureAlbum;

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Create Data Example',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: Scaffold(
//         appBar: AppBar(
//           title: const Text('Create Data Example'),
//         ),
//         body: Container(
//           alignment: Alignment.center,
//           padding: const EdgeInsets.all(8),
//           child: (_futureAlbum == null) ? buildColumn() : buildFutureBuilder(),
//         ),
//       ),
//     );
//   }

//   Column buildColumn() {
//     return Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: <Widget>[
//         TextField(
//           controller: _accountcontroller,
//           decoration: const InputDecoration(hintText: 'Enter account'),
//         ),
//         TextField(
//           controller: _passwordcontroller,
//           decoration: const InputDecoration(hintText: 'Enter password'),
//         ),
//         ElevatedButton(
//           onPressed: () {
//             setState(() {
//               _futureAlbum = createAlbum(
//                   _accountcontroller.text, _passwordcontroller.text);
//             });
//           },
//           child: const Text('Create Data'),
//         ),
//       ],
//     );
//   }

//   FutureBuilder<List<String>> buildFutureBuilder() {
//     return FutureBuilder<List<String>>(
//       future: _futureAlbum,
//       builder: (context, snapshot) {
//         if (snapshot.hasData) {
//           return Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: <Widget>[
//               Text(
//                 snapshot.data![0]??'', // 取得List中的第一個元素
//               ),
//               Text(
//                 snapshot.data![1]??'', // 取得List中的第二個元素
//               ),
//             ],
//           );
//         } else if (snapshot.hasError) {
//           return Text('Error:${snapshot.error}');
//         }

//         return const CircularProgressIndicator();
//       },
//     );
//   }
// }
