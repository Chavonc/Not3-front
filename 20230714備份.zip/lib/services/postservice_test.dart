// import 'dart:async';
// import 'dart:convert';
// import 'package:http/http.dart'as http;
// import 'package:test_spi/models/post_test.dart';

// Future<List<String>> createAlbum(String account, String password) async {
//   final response = await http.post
//   (
//     Uri.parse('http://120.126.16.222/gardeners/login'),
//     headers: <String, String>{
//       'Content-Type': 'application/json; charset=UTF-8',
//       'accept':'application/json',
//     },
//     body: jsonEncode(<String, String>{
//       'account': account,
//       'password': password,
//     }),
//   );
//   if (response.statusCode == 200) 
//   {
//     // If the server did return a 201 CREATED response,
//     // then parse the JSON.
//     final jsonData = jsonDecode(response.body) as Map<String,dynamic>;
//     final album = LoginModel.fromJson(jsonData[0]);
//     return [album.account,album.password];//element[0]，[1]
//   } else {
//     // If the server did not return a 201 CREATED response,
//     // then throw an exception.
//     throw Exception('Error:${response.reasonPhrase},${response.statusCode}');
//   }
// }

