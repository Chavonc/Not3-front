import 'dart:convert';

List<Post> postFromJson(String str) =>
    List<Post>.from(json.decode(str).map((x) => Post.fromJson(x)));
String postToJson(List<Post> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Post 
{
  Post({
    required this.account,//non-null
    required this.password,//non-null
    required this.status,
  });
  String account;
  String password;
  String status;
  factory Post.fromJson(Map<String, dynamic> json) => Post
  (
    account: json['account'],
    password: json['password_hash'],
    status:json['gardener_status'],
  );
  Map<String, dynamic> toJson() => 
  {
    "account":account,
    "password_hash":password,
    "gardener_status":status,
  };
}
