import 'dart:convert';
// import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class LoginModel {
  final String accessToken;
  final String ipAddress;
  const LoginModel({required this.accessToken, required this.ipAddress});
  factory LoginModel.fromJson(Map<String, dynamic> json) {
    return LoginModel(
      //API回傳
      accessToken: json['access_token'],
      ipAddress: json['ip_address'],
    );
  }
}

Future<LoginModel> createLogin(String account, String password) async {
  final response = await http.post(
    Uri.parse(
        'http://120.126.16.222/gardeners/login'), //'https://jsonplaceholder.typicode.com/users'
    headers: <String, String>{'Content-Type': 'application/json;charset=UTF-8'},
    body: jsonEncode(<String, String>{
      //使用者提供
      'account': account,
      'password': password,
    }),
  );
  if (response.statusCode == 200) {
    //final responseData = jsonDecode(response.body);//run type;找出到底拿到的是什麼格式，再從model(creatLogin裡修改格式)
    return LoginModel.fromJson(response.body as Map<String, dynamic>);
  } else {
    throw Exception('${response.reasonPhrase},${response.statusCode}');
  }
}
// class Album 
// {
//   //final int gardenerid;
//   final String account;
//   final String password;
//   const Album
//   ({
//     //required this.gardenerid, 
//     required this.account, 
//     required this.password
//   });

//   factory Album.fromJson(Map<String, dynamic> json) 
//   {
//     return Album(
//       //gardenerid: json['gardener_id'],
//       account: json['access_token']??'',
//       password: json['ip_address']??'',
//     );
//   }
// }
