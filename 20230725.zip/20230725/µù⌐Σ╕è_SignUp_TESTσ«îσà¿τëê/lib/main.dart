import 'package:flutter/material.dart';
//import 'package:test_spi/homepage.dart';
import 'package:test_spi/signup_post.dart';
void main()
{
  runApp(const MyApp());
}

class MyApp extends StatelessWidget
{
  const MyApp({super.key});
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp
    (
      title: 'Post Gardeners Login Data',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const SignUpPage(),
    );
  }
}
// import 'dart:html' as html;
// import 'package:flutter/material.dart';

// void main() {
//   runApp(FileUploadApp());
// }

// class FileUploadApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('檔案上傳示例'),
//         ),
//         body: Center(
//           child: ElevatedButton(
//             onPressed: () {
//               // 點擊按鈕時觸發檔案選擇動作
//               selectFile();
//             },
//             child: Text('選擇檔案'),
//           ),
//         ),
//       ),
//     );
//   }

//   void selectFile() {
//     final html.FileUploadInputElement input = html.FileUploadInputElement();
//     input.click();

//     input.onChange.listen((event) {
//       final files = input.files;
//       if (files?.length == 1) {
//         final file = files?[0];
//         // 在這裡可以處理選擇的檔案，比如上傳至伺服器
//         print('檔案名稱: ${file!.name}');
//         print('檔案大小: ${file.size} bytes');
//         print('檔案類型: ${file.type}');
//       }
//     });
//   }
// }
// import 'dart:html' as html;
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// void main() {
//   runApp(FileUploadApp());
// }

// class FileUploadApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('檔案上傳示例'),
//         ),
//         body: Center(
//           child: ElevatedButton(
//             onPressed: () {
//               // 點擊按鈕時觸發檔案選擇動作
//               selectFile();
//             },
//             child: Text('選擇檔案'),
//           ),
//         ),
//       ),
//     );
//   }

//   void selectFile() {
//     final html.FileUploadInputElement input = html.FileUploadInputElement();
//     input.click();

//     input.onChange.listen((event) async {
//       final files = input.files;
//       if (files?.length == 1) {
//         final file = files?[0];
//         // 將選擇的檔案轉換為二進位數據
//         final reader = html.FileReader();
//         reader.readAsDataUrl(file!);

//         reader.onLoadEnd.listen((event) async {
//           // 獲取二進位數據
//           final encodedData = reader.result.toString().split(',')[1];

//           // 上傳檔案至伺服器
//           await uploadFileToServer(file.name, encodedData);
//         });
//       }
//     });
//   }

//   Future<void> uploadFileToServer(String fileName, String data) async {
//     // 將二進位數據上傳至伺服器
//     final response = await http.post(
//       Uri.parse('http://120.126.16.222/gardeners/signup-test'), // 將YOUR_UPLOAD_URL替換為實際的上傳URL
//       body: {
//         'file_name': fileName,
//         'data': data,
//       },
//     );

//     // 處理伺服器回應
//     if (response.statusCode == 200) {
//       print('檔案上傳成功！');
//     } else {
//       print('檔案上傳失敗，錯誤碼: ${response.statusCode}');
//     }
//   }
// }
// import 'dart:html' as html;
// import 'dart:typed_data';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// void main() 
// {
//   runApp(const Test());
// }
// class Test extends StatefulWidget
// {
//   const Test({Key? key}) : super(key: key);
//   @override
//   // ignore: library_private_types_in_public_api
//   _TestState createState() => _TestState();
// }

// class _TestState extends State<Test>
// {
//   final TextEditingController _firstnamecontroller=TextEditingController();
//   final TextEditingController _accountcontroller = TextEditingController();
//   final TextEditingController _passwordcontroller = TextEditingController();

//   @override
//   Widget build(BuildContext context) 
//   {
//     return MaterialApp
//     (
//       home: Scaffold
//       (
//         appBar: AppBar
//         (
//           title: const Text('檔案上傳示例'),
//         ),
//         body: Center
//         (
//           child: Column
//           (
//             children: <Widget>
//             [
//               SizedBox
//               (
//                 width: 300,
//                 height: 80,
//                 child: TextField
//                 (
//                   controller: _accountcontroller,
//                   decoration: const InputDecoration
//                   (
//                     hintText: 'Enter Account',
//                     labelText: "帳號",
//                     prefixIcon: Icon(Icons.person_4),
//                   ),
//                 ),
//               ),
//               SizedBox
//               (
//                 width: 300,
//                 height: 80,
//                 child: TextField
//                 (
//                   controller: _firstnamecontroller,
//                   decoration: const InputDecoration
//                   (
//                     hintText: 'Enter Firstname',
//                     labelText: "名字",
//                     prefixIcon: Icon(Icons.person),
//                   ),
//                 ),
//               ),
//               SizedBox
//               (
//                 width: 300,
//                 height: 80,
//                 child: TextField
//                 (
//                   controller: _passwordcontroller,
//                   obscureText: true,
//                   decoration: const InputDecoration
//                   (
//                     hintText: 'Enter Password',
//                     labelText: "密碼",
//                     prefixIcon: Icon(Icons.lock),
//                   ),
//                 ),
//               ),
//               ElevatedButton
//               (
//                 onPressed: () 
//                 {
//                   // 點擊按鈕時觸發檔案選擇動作
//                   selectAndUploadFile(_accountcontroller.text,_passwordcontroller.text,_firstnamecontroller.text);
//                 },
//                 child: const Text('選擇檔案並上傳'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Future <void> selectAndUploadFile(String account,String password,String firstname) async 
//   {
//     final html.FileUploadInputElement input = html.FileUploadInputElement();
//     input.click();

//     await input.onChange.first;
//     final file = input.files![0];

//     // 使用FileReader讀取檔案內容
//     final reader = html.FileReader();
//     reader.readAsArrayBuffer(file);

//     // 等待讀取完成
//     await reader.onLoad.first;

//     // 獲取Uint8List作為Stream<List<int>>來傳遞給http.MultipartFile
//     final uint8List = reader.result as Uint8List;

//     // 建立form-data
//     final formData = http.MultipartRequest('POST', Uri.parse('http://120.126.16.222/gardeners/signup-test'));

//     // 將檔案加入form-data中
//     formData.files.add(http.MultipartFile.fromBytes
//     (
//       'file', // 表單中的檔案字段名
//       uint8List, // 檔案內容
//       filename: file.name, // 圖檔名稱
//     ));

//     // 可以加入其他參數
//     formData.fields['account'] = account;
//     formData.fields['password'] = password;
//     formData.fields['first_name'] = firstname;
//     // 發送form-data請求
//     final response = await formData.send();

//     // 等待伺服器回應
//     final responseText = await response.stream.bytesToString();
//     print('伺服器回應：$responseText');
//   }
// }
