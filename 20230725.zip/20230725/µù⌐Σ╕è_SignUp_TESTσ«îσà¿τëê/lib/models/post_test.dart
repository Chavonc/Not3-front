import 'dart:convert';
import 'dart:developer';
// import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class LoginModel 
{
  //回傳什麼就設什麼
  final String accessToken;
  final String ipAddress;
  const LoginModel({required this.accessToken, required this.ipAddress});

  factory LoginModel.fromJson(Map<String, dynamic> json) //API會給你的資料
  {
    return LoginModel
    (
      //API return
      accessToken: json['access_token'],
      ipAddress: json['ip_address'],
    );
  }
}
Future<List<dynamic>> createLogin(String account, String password) async // Future<LoginModel>
{
  final response = await http.post
  (
    Uri.parse('http://120.126.16.222/gardeners/login'), 
    headers: <String, String>{'Content-Type': 'application/json;charset=UTF-8'},//一定要問後端或看server postman
    body: jsonEncode(<String, String>//Encode,你要給什麼資料?
    {
      //input
      'account': account,
      'password': password,
    }),
  );
  if (response.statusCode >= 200&& response.statusCode<300) 
  {
    List<dynamic> body = jsonDecode(response.body);
    return body;
  } 
  else //Error
  {
    //測試到底有沒有接收到資料
    log(response.body);
    log('${response.statusCode}');
    throw Exception('${response.reasonPhrase},${response.statusCode}');
  }
}